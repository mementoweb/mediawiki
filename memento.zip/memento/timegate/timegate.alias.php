<?php
    /**
    * Aliases for special pages
    *
    * @file
    * @ingroup Extensions
    */

    $aliases = array();

    /** English */
    $aliases['en'] = array(
        'TimeGate' => array( 'TimeGate' ),
    );
